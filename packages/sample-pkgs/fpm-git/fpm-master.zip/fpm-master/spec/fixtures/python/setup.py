from setuptools import setup

setup(name="Example",
      version="1.0",
      description="sample description",
      author="sample author",
      author_email="sample email",
      url="sample url",
      packages=[],
      package_dir={},
      install_requires=["Dependency1", "dependency2"],
      )

